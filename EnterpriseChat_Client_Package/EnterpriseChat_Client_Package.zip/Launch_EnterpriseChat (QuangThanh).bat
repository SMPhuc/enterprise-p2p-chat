﻿@echo off
chcp 65001 >nul
cd /d "%~dp0"
title EnterpriseSecretChat - Quang Thanh
cls
echo ================================================================
echo   ENTERPRISE SECRET CHAT - SECURE CLIENT LAUNCHER
echo   Nguoi dung: Quang Thanh
echo ================================================================
echo.
echo [*] Dang tu dong ket noi Server Relay trong mang LAN...
echo.

if exist "EnterpriseSecretChat.exe" (
    EnterpriseSecretChat.exe "Quang Thanh"
) else if exist "EnterpriseChat_Client_Package\EnterpriseSecretChat.exe" (
    cd /d "%~dp0EnterpriseChat_Client_Package"
    EnterpriseSecretChat.exe "Quang Thanh"
) else (
    python app_client.py "Quang Thanh" 127.0.0.1 8888 SNGZ4hZg4ORvwq63v1IloK8j9wXB0r1k5Roc501TUKiB353xVM
)

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [ERROR] Ung dung gap su co. Ma loi: %ERRORLEVEL%
    pause
)

